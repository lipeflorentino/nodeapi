// Importa o controller
const appController = require('../controllers/appController');
require('dotenv').config();
console.log('cheguei na rota!');
const $secret = process.env.SECRET;
const router = app => {
    // middleware para validar o Token
    

    app.get('/', (request, response) => {
        response.send({
            message: 'Node.js and Express REST API haha'
        });
    });
    
    // Add a new user
    app.route('/users').post(appController.enviarEmail);
    // Delete a user
    app.route('/users/:id').delete(appController.deletarUser);
}


// Export the router
module.exports = router;